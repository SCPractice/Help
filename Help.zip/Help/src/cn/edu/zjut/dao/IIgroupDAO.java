package cn.edu.zjut.dao;

import cn.edu.zjut.po.Igroup;

public interface IIgroupDAO {
	public boolean create(Igroup igroup);
}
