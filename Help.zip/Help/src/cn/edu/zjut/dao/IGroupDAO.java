package cn.edu.zjut.dao;

import java.util.List;

public interface IGroupDAO {

	List findByHQL(String hql);
}
