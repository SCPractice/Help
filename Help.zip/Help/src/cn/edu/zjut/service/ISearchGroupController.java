package cn.edu.zjut.service;

import cn.edu.zjut.po.Igroup;

public interface ISearchGroupController {

	boolean search(Igroup group);
	boolean join(Igroup group);
}
