package cn.edu.zjut.service;


import java.util.List;



public interface IEmployeeTeamController {
	public List findTeam();
	public boolean  updateIgroupID();
	public boolean exitTeam();
}
