package cn.edu.zjut.service;

import cn.edu.zjut.po.Igroup;

public interface IEmployeeCreateTeamController {
	public boolean create(Igroup igroup);
}
